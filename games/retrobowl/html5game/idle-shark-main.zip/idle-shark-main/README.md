# Idle Shark
The best ocean idle game ever made

## Badges

<html>
<p>
<img alt="GitHub last commit" src="https://img.shields.io/github/last-commit/3kh0/idle-shark?color=red&label=Lastest%20commit&logo=github">
<img alt="GitHub contributors" src="https://img.shields.io/github/contributors/3kh0/idle-shark?color=purple&label=Contributors&logo=github">
<img alt="GitHub forks" src="https://img.shields.io/github/forks/3kh0/idle-shark?label=Forks&logo=github">
<img alt="GitHub Repo stars" src="https://img.shields.io/github/stars/3kh0/idle-shark?color=yellow&label=Stars&logo=github">
<img alt="GitHub" src="https://img.shields.io/github/license/3kh0/idle-shark?label=License&logo=github">
<img alt="GitHub issues" src="https://img.shields.io/github/issues/3kh0/idle-shark?label=Issues&logo=github">
<img alt="GitHub pull requests" src="https://img.shields.io/github/issues-pr/3kh0/idle-shark?color=yellow&label=Pull%20Requests&logo=github">
  </p>
  </html>
  
  ## Play
  
  ### Stable
  
  You can play the stable version with the link below:
  
  **[https://3kh0.github.io/idle-shark/](https://3kh0.github.io/idle-shark/)**
  
  ### Test build
  
  Currently only selected people have access to the dev version.
  
  If you would like to be invited to test *unstable* games then join my [discord server](https://dsc.gg/3kh0/).
  
  ## Thank you for playing!
