Upgrades from the `lab` tab.
