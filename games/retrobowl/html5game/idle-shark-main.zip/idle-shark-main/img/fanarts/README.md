This is just some extra art that was not added.
