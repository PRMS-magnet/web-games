import stripe
import time
import sendemail
import genkey
import time
import os
import json

api_url = "http://207.246.81.177:8080"  # Ensure the URL matches your running server
api_key = "paGrim-mufyo9-viswos"

# Set your Stripe secret key (test mode)
stripe.api_key = "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"

# Your specific product ID in test mode
SPECIFIC_PRODUCT_ID = "prod_RcMawJetSbq2nc"

# File to store processed emails
EMAILS_FILE = "purchased_emails.txt"

def load_emails():
    if os.path.exists(EMAILS_FILE):
        with open(EMAILS_FILE, "r") as file:
            return set(email.strip() for email in file if email.strip())
    return set()

# Save a single email to the file
def save_email(email):
    with open(EMAILS_FILE, "a") as file:
        file.write(email + "\n")

# Check for new purchases and process them
def check_new_purchases(processed_emails):
    try:
        # Fetch the latest events from Stripe
        events = stripe.Event.list(limit=10)

        for event in events.data:
            # Look for 'checkout.session.completed' events
            if event["type"] == "checkout.session.completed":
                session = event["data"]["object"]

                # Retrieve the line items to check the purchased product
                line_items = stripe.checkout.Session.list_line_items(session["id"])

                for item in line_items.data:
                    if item["price"]["product"] == SPECIFIC_PRODUCT_ID:
                        custom_fields = session.get("custom_fields", [])

                        for field in custom_fields:
                            email = field.get("text", {}).get("value")
                            if email and email not in processed_emails:
                                processed_emails.add(email)
                                save_email(email)
                                print(f"New purchase detected! Email: {email}")
                                key = genkey.generate_key_from_server(api_url, email, api_key)
                                sendemail.email_key(key, email)
                            elif email is None:
                                print("Custom field missing")



                        # Only add email if it hasn't been processed


    except stripe.error.StripeError as e:
        print(f"Stripe API error: {e.user_message}")
    except Exception as e:
        print(f"Unexpected error: {e}")

if __name__ == "__main__":
    print("Tracking new purchases...")

    # Load processed emails into memory
    processed_emails = load_emails()

    # Run the script in a loop
    while True:
        check_new_purchases(processed_emails)
        time.sleep(5)  # Check every 30 seconds