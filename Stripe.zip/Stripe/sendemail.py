import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def email_key(key, email):
    subject = "Thank you for purchasing iReadyAI! Key and information here."
    body = f"""Hi, thank you for purchasing iReadyAI. You will also get iReadyAuto once it comes out. This key will work for both softwares.

    [Click here to download.](google.com)

    {key}

    Make sure you have bought the product with the email you are using for I-Ready, or else the program will not login to I-Ready correctly, if you have made a mistake, please contact the support email.

    Support email: nexus.hecker@gmail.com

    -Nexus




    This is a noreply email. Do not reply to this email because we wont check responses. If you require support, email the support email instead please."""

    html="""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>iReadyAI Purchase Confirmation</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                background-color: #f9f9f9;
                margin: 0;
                padding: 0;
            }
            .email-container {
                max-width: 600px;
                margin: 20px auto;
                background: #ffffff;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 20px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            .header {
                font-size: 20px;
                font-weight: bold;
                margin-bottom: 15px;
            }
            .content {
                font-size: 16px;
                margin-bottom: 20px;
            }
            .key {
                font-size: 16px;
                color: #1a73e8;
                font-weight: bold;
                word-break: break-word;
            }
            .link {
                font-size: 16px;
                color: #ffffff;
                background-color: #1a73e8;
                padding: 10px 15px;
                text-decoration: none;
                border-radius: 4px;
            }
            .link:hover {
                background-color: #155bb5;
            }
            .footer {
                font-size: 14px;
                color: #888;
                margin-top: 20px;
                text-align: center;
            }
            .support-email {
                color: #1a73e8;
                text-decoration: none;
            }
        </style>
    </head>
    <body>
        <div class="header">Thank you for purchasing iReadyAI!</div>
        <div class="content">
            Hi, thank you for purchasing <strong>iReadyAI</strong>. You will also get <strong>iReadyAuto</strong> once it comes out. This key will work for both software.
        </div>
        <div class="content">
            <a href="https://google.com" class="link">Click here to download</a>
        </div>
        <div class="content">
            <div><strong>Your Key:</strong></div>
            <div class="key">{key}</div>
        </div>
        <div class="content">
            Make sure you have purchased the product with the email you are using for I-Ready, or else the program will not log in to I-Ready correctly. If you have made a mistake, please contact the support email.
        </div>
        <div class="content">
            <strong>Support email:</strong> <a href="mailto:nexus.hecker@gmail.com" class="support-email">nexus.hecker@gmail.com</a>
        </div>
        <div class="footer">
            - Nexus<br><br>
            This is a <strong>noreply</strong> email. Do not reply to this email because we won't check responses. If you require support, please email the support email instead.
        </div>
    </body>
    </html>
    """.replace("{key}", key)
    sender = "nexushackers.noreply@gmail.com"
    recipients = email
    password = "waui uxbc jqrp sxio"


    def send_email(subject, body, sender, recipients, password):
        msg = MIMEMultipart("alternative")
        part1 = MIMEText(body, "plain")
        part2 = MIMEText(html, "html")
        msg.attach(part1)
        msg.attach(part2)
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = recipients
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp_server:
            smtp_server.login(sender, password)
            smtp_server.sendmail(sender, recipients, msg.as_string())
            print("Message sent!")


    send_email(subject, body, sender, recipients, password)